# Konstantinos Foskolakis n8n Portfolio

Start here.

## Public Links

- Live portfolio: https://n8n-local-automation-portfolio.vercel.app
- GitHub repository: https://github.com/kostasuser01gr/n8n-local-automation-portfolio
- GitHub Release: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/releases/tag/v0.2.0

## What This Package Contains

- One-page portfolio summary.
- Application cover note.
- Technical highlights.
- Project summary.
- Repository links.
- Demo guide.
- Three strongest execution screenshots.
- Sanitized workflow JSON exports.
- Sample data.
- Architecture notes.
- Case studies.
- Evidence summary.
- License.

## Verification Boundary

The included counts are small deterministic sample-data evidence. They prove local workflow execution and PostgreSQL persistence. They do not claim scale, outside adoption, or hosted workflow operation.

## Best Review Path

1. Open `PORTFOLIO_ONE_PAGE.md`.
2. Open the live portfolio URL.
3. Review `PROJECT_SUMMARY.md`.
4. Inspect `screenshots/`.
5. Inspect `workflows/`.
6. Use `DEMO_GUIDE.md` for a five-minute walkthrough.
