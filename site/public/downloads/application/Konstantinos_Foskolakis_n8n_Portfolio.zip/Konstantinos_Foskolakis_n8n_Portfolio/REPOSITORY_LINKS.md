# Repository Links

## Primary Links

- Live Vercel portfolio: https://n8n-local-automation-portfolio.vercel.app
- GitHub repository: https://github.com/kostasuser01gr/n8n-local-automation-portfolio
- GitHub Release: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/releases/tag/v0.2.0

## Project Pages

- Job Application Intelligence: https://n8n-local-automation-portfolio.vercel.app/projects/job-application-intelligence
- Fleet Operations: https://n8n-local-automation-portfolio.vercel.app/projects/fleet-operations
- Local AI Knowledge: https://n8n-local-automation-portfolio.vercel.app/projects/local-ai-knowledge

## Public Repository Sections

- Workflows: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/tree/main/workflows
- Screenshots: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/tree/main/screenshots
- Case studies: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/tree/main/case-studies
- Execution summary: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/blob/main/docs/EXECUTION_SUMMARY.md
