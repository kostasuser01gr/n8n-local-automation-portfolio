# n8n Application One Page

Live portfolio: https://n8n-local-automation-portfolio.vercel.app
Repository: https://github.com/kostasuser01gr/n8n-local-automation-portfolio
Release: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/releases/tag/v0.2.0

Repository: https://github.com/kostasuser01gr/n8n-local-automation-portfolio

Release: https://github.com/kostasuser01gr/n8n-local-automation-portfolio/releases/tag/v0.2.0

## Candidate Positioning

Hands-on n8n workflow engineer with verified local-first delivery: self-hosted n8n, PostgreSQL persistence, Docker/Colima operations, workflow debugging, release sanitization, documentation, and reviewer-ready packaging.

## Verified Projects

- Job Application Intelligence Pipeline: persisted `job_applications=2`, `job_import_runs=1`, `job_import_rejections=0`.
- Fleet Operations Automation System: persisted `fleet_vehicles=3`, `fleet_operation_runs=1`.
- Local AI Knowledge Workflow: persisted `knowledge_documents=3`, `knowledge_processing_runs=1`.

## Strongest Technical Signals

- Executed workflows, not only exported JSON.
- PostgreSQL row counts used as persistence proof.
- Authenticated n8n screenshots included.
- Sanitized workflow exports and release assets.
- Validation and secret-scan scripts included.
- GitHub Release `v0.2.0` published with sanitized workflow JSON assets.

## Debugging Story

The most useful debugging path was resolving real local execution blockers: a CLI execution conflict and a scoped n8n file-access issue. The fix was narrow: isolate the execution path, configure file access deliberately, rerun the workflow, and verify persistence through PostgreSQL.

## Stack

n8n, PostgreSQL, Docker, Colima, macOS Apple Silicon, local sample data, shell validation scripts, GitHub release packaging.

## Security And Release Practices

No live `.env`, credentials, database files, backups, or credential exports are included. Release artifacts were sanitized, screenshots reviewed, and scripts validate JSON plus secret-like markers.

## Contribution Intent

Contribute practical n8n examples, workflow templates, debugging writeups, and documentation that help users reproduce, inspect, and adapt workflows safely.

## Five Strongest Screenshots

1. `screenshots/job-tracker/successful-execution-green-nodes.png`
2. `screenshots/fleet-operations/successful-execution-green-nodes.png`
3. `screenshots/local-ai-knowledge/successful-execution-green-nodes.png`
4. `screenshots/job-tracker/workflow-canvas.png`
5. `assets/social-preview.png`

## Limitations

The data is small deterministic sample data. The portfolio proves execution, persistence, debugging, and packaging. It does not claim outside adoption, hosted availability, paid integration traffic, or broad deployment.

Contact: `[name]`, `[email or profile link]`
